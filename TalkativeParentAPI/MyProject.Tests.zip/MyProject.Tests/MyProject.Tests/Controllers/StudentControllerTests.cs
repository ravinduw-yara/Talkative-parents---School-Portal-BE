﻿using Moq;
using Xunit;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using CommonUtility.RequestModels;
using Services;
using TalkativeParentAPI.Controllers;

public class StudentControllerTests
{
    private readonly Mock<IMChildinfoService> _mockChildinfoService;
    private readonly ParentsController _controller;

    public StudentControllerTests()
    {
        // Mock the IMChildinfoService
        _mockChildinfoService = new Mock<IMChildinfoService>();

        // Initialize the controller with only IMChildinfoService
        _controller = new ParentsController(
            null,  // IMSchooluserinfoService
            _mockChildinfoService.Object,  // IMChildinfoService
            null,  // IMSchooluserroleService
            null,  // IMChildschoolmappingService
            null,  // IMParentchildmappingService
            null,  // IMAppuserinfoService
            null,  // IMStandardsectionmappingService
            null,  // GoogleDriveService
            null,  // IMQuetionPaperService
            null,  // IConfiguration
            null,  // MUploadPdfGoogleDriveService
            null,  // MUploadPdfSyllabusGoogleDriveService
            null,  // IMSyllabusService
            null   // IDataAnalysisServices
        );
    }

    [Fact]
    public async Task GetStudentDetailsByChildId_ReturnsOkResult()
    {
        // Arrange
        var token = Guid.NewGuid();
        var schoolId = 78;
        var childId = 18026;
        var academicYearId = 20;

        var mockStudentDetails = new GetParentsListModel
        {
            ChildId = childId
        };

        var mockApiResponse = new ApiResponse
        {
            Items = new List<GetParentsListModel> { mockStudentDetails }
        };

        _mockChildinfoService
            .Setup(service => service.GetStudentDetailsByChildIdForAPI(token, schoolId, childId, academicYearId, 10, 1))
            .ReturnsAsync(mockApiResponse);

        // Act
        var result = await _controller.GetStudentDetailsByChildId(token, schoolId, childId, academicYearId);

        // Assert
        var okResult = Assert.IsType<OkObjectResult>(result);
        var responseObject = okResult.Value;

        // Cast the responseObject to its expected type (anonymous type is known)
        var typedResult = responseObject.GetType().GetProperty("StudentDetails").GetValue(responseObject, null);
        var studentDetails = typedResult as GetParentsListModel;

        Assert.NotNull(studentDetails);
        Assert.Equal(childId, studentDetails.ChildId);
    }

    [Fact]
    public async Task GetStudentDetailsByChildId_ReturnsNotFound_WhenNoData()
    {
        // Arrange
        var token = Guid.NewGuid();
        var schoolId = 78;
        var childId = 18026;
        var academicYearId = 20;

        _mockChildinfoService
            .Setup(service => service.GetStudentDetailsByChildIdForAPI(token, schoolId, childId, academicYearId, 10, 1))
            .ReturnsAsync(new ApiResponse { Items = null });

        // Act
        var result = await _controller.GetStudentDetailsByChildId(token, schoolId, childId, academicYearId);

        // Assert
        Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public async Task GetStudentDetailsByChildId_ReturnsBadRequest_OnException()
    {
        // Arrange
        var token = Guid.NewGuid();
        var schoolId = 78;
        var childId = 18026;
        var academicYearId = 20;

        _mockChildinfoService
            .Setup(service => service.GetStudentDetailsByChildIdForAPI(It.IsAny<Guid>(), It.IsAny<int>(), It.IsAny<int>(), It.IsAny<int>(), 10, 1))
            .ThrowsAsync(new Exception("Test exception"));

        // Act
        var result = await _controller.GetStudentDetailsByChildId(token, schoolId, childId, academicYearId);

        // Assert
        var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);

        // Use a known structure for the anonymous object instead of dynamic
        var response = badRequestResult.Value as IDictionary<string, object>;

        // Assert the exception message
        Assert.NotNull(response);
        Assert.Equal("Test exception", response["Data"]);
    }
}
